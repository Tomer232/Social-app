package com.example.socialapp.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.appcompat.widget.Toolbar;

import com.example.socialapp.R;
import com.example.socialapp.adapter.HomePostAdapter;
import com.example.socialapp.model.HomePostModel;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import java.util.ArrayList;
import java.util.List;

public class HomeFragment extends Fragment {

    private static final String TAG = "HomeFragment";

    private RecyclerView recyclerView;
    private SwipeRefreshLayout swipeRefreshLayout;
    private HomePostAdapter homePostAdapter;
    private List<HomePostModel> posts;

    private FirebaseFirestore db;
    private FirebaseAuth mAuth;
    private String currentUserId;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        Toolbar toolbar = view.findViewById(R.id.toolbar);
        recyclerView = view.findViewById(R.id.recyclerView);
        swipeRefreshLayout = view.findViewById(R.id.swipeRefreshLayout);

        db = FirebaseFirestore.getInstance();
        mAuth = FirebaseAuth.getInstance();
        currentUserId = mAuth.getCurrentUser().getUid();

        posts = new ArrayList<>();
        homePostAdapter = new HomePostAdapter(getContext(), posts, currentUserId);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setAdapter(homePostAdapter);

        swipeRefreshLayout.setOnRefreshListener(this::loadPosts);

        loadPosts();

        return view;
    }

    private void showToast(String message) {
        if (getContext() != null && isAdded()) {
            Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
        }
    }

    private void loadPosts() {
        swipeRefreshLayout.setRefreshing(true);
        db.collection("posts")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .limit(50) // Limit the number of posts to avoid performance issues
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    posts.clear();
                    for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                        HomePostModel post = document.toObject(HomePostModel.class);
                        post.setPostId(document.getId());
                        posts.add(post);
                        Log.d(TAG, "Loaded post: " + post.getPostId() + " from user: " + post.getUserId());
                    }
                    homePostAdapter.notifyDataSetChanged();
                    checkLikeStatusForAllPosts();
                    swipeRefreshLayout.setRefreshing(false);
                    if (posts.isEmpty()) {
                        Log.d(TAG, "No posts found");
                        showToast("No posts found.");
                    } else {
                        Log.d(TAG, "Loaded " + posts.size() + " posts");
                    }
                })
                .addOnFailureListener(e -> {
                    swipeRefreshLayout.setRefreshing(false);
                    Log.e(TAG, "Error loading posts: ", e);
                    showToast("Error Loading posts.");
                });
    }

    private void checkLikeStatusForAllPosts() {
        for (HomePostModel post : posts) {
            db.collection("posts").document(post.getPostId()).collection("likes").document(currentUserId).get()
                    .addOnSuccessListener(documentSnapshot -> {
                        boolean isLiked = documentSnapshot.exists();
                        post.setLikedByCurrentUser(isLiked);
                        homePostAdapter.notifyItemChanged(posts.indexOf(post));
                    });
        }
    }
}