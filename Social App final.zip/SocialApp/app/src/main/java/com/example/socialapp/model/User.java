package com.example.socialapp.model;

import java.util.ArrayList;
import java.util.List;

public class User {
    private String userId;
    private String name;
    private String email;
    private String profilePicUrl;
    private List<String> following;
    private List<String> followers;

    public User(String userId, String name, String email, String profilePicUrl) {
        this.userId = userId;
        this.name = name;
        this.email = email;
        this.profilePicUrl = profilePicUrl;
        this.following = new ArrayList<>();
        this.followers = new ArrayList<>();
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getProfilePicUrl() {
        return profilePicUrl;
    }

    public void setProfilePicUrl(String profilePicUrl) {
        this.profilePicUrl = profilePicUrl;
    }

    public List<String> getFollowing() {
        return following;
    }

    public void setFollowing(List<String> following) {
        this.following = following;
    }

    public List<String> getFollowers() {
        return followers;
    }

    public void setFollowers(List<String> followers) {
        this.followers = followers;
    }

    public void addFollowing(String userId) {
        if (!this.following.contains(userId)) {
            this.following.add(userId);
        }
    }

    public void addFollower(String userId) {
        if (!this.followers.contains(userId)) {
            this.followers.add(userId);
        }
    }

}