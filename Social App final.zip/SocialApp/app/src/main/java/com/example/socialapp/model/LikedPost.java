package com.example.socialapp.model;

import com.google.firebase.Timestamp;

public class LikedPost {
    private String postId;
    private String userId;
    private Timestamp timestamp;

    public LikedPost() {}

    public LikedPost(String postId, String userId, Timestamp timestamp) {
        this.postId = postId;
        this.userId = userId;
        this.timestamp = timestamp;
    }

    // Getters and setters
    public String getPostId() {
        return postId;
    }

    public void setPostId(String postId) {
        this.postId = postId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }
}