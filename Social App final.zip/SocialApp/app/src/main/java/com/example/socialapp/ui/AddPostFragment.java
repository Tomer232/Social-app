package com.example.socialapp.ui;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.bumptech.glide.Glide;
import com.example.socialapp.R;
import com.example.socialapp.model.AddPost;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.util.UUID;

public class AddPostFragment extends Fragment {

    private static final int PICK_IMAGE_REQUEST = 1;

    private ImageView ivPostImage;
    private Button btnChooseImage, btnPost;
    private EditText etCaption;

    private Uri imageUri;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private StorageReference storageRef;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add_photo, container, false);

        ivPostImage = view.findViewById(R.id.ivPostImage);
        btnChooseImage = view.findViewById(R.id.btnChooseImage);
        btnPost = view.findViewById(R.id.btnPost);
        etCaption = view.findViewById(R.id.etCaption);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        storageRef = FirebaseStorage.getInstance().getReference();

        btnChooseImage.setOnClickListener(v -> openImageChooser());
        btnPost.setOnClickListener(v -> uploadPost());

        return view;
    }

    private void openImageChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == getActivity().RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();
            Glide.with(this).load(imageUri).into(ivPostImage);
        }
    }

    private void uploadPost() {
        if (imageUri == null) {
            Toast.makeText(getContext(), "Please select an image", Toast.LENGTH_SHORT).show();
            return;
        }

        String caption = etCaption.getText().toString().trim();
        String userId = mAuth.getCurrentUser().getUid();
        String postId = UUID.randomUUID().toString();

        StorageReference postImageRef = storageRef.child("post_images/" + postId + ".jpg");
        postImageRef.putFile(imageUri)
                .addOnSuccessListener(taskSnapshot -> postImageRef.getDownloadUrl()
                        .addOnSuccessListener(uri -> {
                            String imageUrl = uri.toString();
                            savePostToFirestore(postId, userId, imageUrl, caption);
                        }))
                .addOnFailureListener(e -> Toast.makeText(getContext(), "Failed to upload image", Toast.LENGTH_SHORT).show());
    }

    private void savePostToFirestore(String postId, String userId, String imageUrl, String caption) {
        AddPost post = new AddPost(postId, userId, imageUrl, caption);
        db.collection("posts").document(postId).set(post)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(getContext(), "Post uploaded successfully", Toast.LENGTH_SHORT).show();
                    clearForm();
                })
                .addOnFailureListener(e -> Toast.makeText(getContext(), "Failed to save post", Toast.LENGTH_SHORT).show());
    }

    private void clearForm() {
        ivPostImage.setImageResource(R.drawable.gallery);
        etCaption.setText("");
        imageUri = null;
    }
}