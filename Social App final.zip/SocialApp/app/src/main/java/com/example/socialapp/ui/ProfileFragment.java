package com.example.socialapp.ui;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.socialapp.LoginActivity;
import com.example.socialapp.R;
import com.example.socialapp.adapter.ProfilePostsAdapter;
import com.example.socialapp.model.AddPost;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class ProfileFragment extends Fragment {

    private static final int PICK_IMAGE_REQUEST = 1;

    private ImageView editProfileIcon;
    private Uri imageUri;
    private CircleImageView profileImageView;
    private TextView nameTextView;
    private RecyclerView postsRecyclerView;
    private ProfilePostsAdapter profilePostsAdapter;
    private List<AddPost> posts;
    private CircleImageView dialogProfileImage;
    private FirebaseAuth mAuth;
    private FirebaseFirestore db;
    private FirebaseStorage storage;
    private String userId;
    private DrawerLayout drawerLayout;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_profile, container, false);

        drawerLayout = view.findViewById(R.id.drawerLayout);
        ImageView settingsButton = view.findViewById(R.id.settingsButton);

        settingsButton.setOnClickListener(v -> drawerLayout.openDrawer(GravityCompat.END));

        setupSidebarButtons(view);
        profileImageView = view.findViewById(R.id.profile_image);
        nameTextView = view.findViewById(R.id.profile_name);
        postsRecyclerView = view.findViewById(R.id.posts_recycler_view);

        mAuth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        storage = FirebaseStorage.getInstance();
        userId = mAuth.getCurrentUser().getUid();

        posts = new ArrayList<>();
        profilePostsAdapter = new ProfilePostsAdapter(getContext(), posts);
        postsRecyclerView.setLayoutManager(new GridLayoutManager(getContext(), 3));
        postsRecyclerView.setAdapter(profilePostsAdapter);

        editProfileIcon = view.findViewById(R.id.edit_profile_icon);
        editProfileIcon.setOnClickListener(v -> showEditProfileDialog());

        loadUserProfile();
        loadUserPosts();

        return view;
    }
    private void setupSidebarButtons(View view) {
        Button savedPostsButton = drawerLayout.findViewById(R.id.savedPostsButton);
        Button logoutButton = drawerLayout.findViewById(R.id.logoutButton);

        if (savedPostsButton == null || logoutButton == null) {
            return;
        }

        savedPostsButton.setOnClickListener(v -> {
            getParentFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new SavedPostsFragment())
                    .addToBackStack(null)
                    .commit();
            drawerLayout.closeDrawer(GravityCompat.END);
        });

        logoutButton.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            // Navigate to LoginActivity
            startActivity(new Intent(getActivity(), LoginActivity.class));
            getActivity().finish();
        });
    }
    private void loadUserProfile() {
        db.collection("users").document(userId).get()
                .addOnSuccessListener(document -> {
                    if (document.exists()) {
                        String name = document.getString("name");
                        nameTextView.setText(name);

                        String profilePicUrl = document.getString("profilePicUrl");
                        if (profilePicUrl != null && !profilePicUrl.isEmpty()) {
                            loadProfileImage(Uri.parse(profilePicUrl));
                        } else {
                            profileImageView.setImageResource(R.drawable.ic_profile);
                        }
                    }
                });
    }

    private void loadUserPosts() {
        db.collection("posts").whereEqualTo("userId", userId).get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    posts.clear();
                    for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                        AddPost post = document.toObject(AddPost.class);
                        if (document.contains("likesCount")) {
                            post.setLikesCount(document.getLong("likesCount").intValue());
                        } else {
                            post.setLikesCount(0);
                        }
                        posts.add(post);
                    }
                    profilePostsAdapter.notifyDataSetChanged();
                });
    }
    private void showEditProfileDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireContext());
        View dialogView = getLayoutInflater().inflate(R.layout.dialog_edit_profile, null);
        builder.setView(dialogView);

        dialogProfileImage = dialogView.findViewById(R.id.dialog_profile_image);
        EditText dialogNameEdit = dialogView.findViewById(R.id.dialog_name_edit);
        Button selectImageButton = dialogView.findViewById(R.id.select_image_button);

        // Set current values
        Glide.with(requireContext())
                .load(profileImageView.getDrawable())
                .into(dialogProfileImage);
        dialogNameEdit.setText(nameTextView.getText());

        selectImageButton.setOnClickListener(v -> openImageChooser());

        // Create custom buttons
        LinearLayout buttonLayout = new LinearLayout(requireContext());
        buttonLayout.setOrientation(LinearLayout.HORIZONTAL);
        buttonLayout.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        buttonLayout.setPadding(32, 16, 32, 16);

        Button cancelButton = new Button(requireContext());
        cancelButton.setText("Cancel");
        cancelButton.setBackgroundColor(getResources().getColor(android.R.color.black));
        cancelButton.setTextColor(getResources().getColor(android.R.color.white));
        LinearLayout.LayoutParams cancelParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        cancelParams.setMarginEnd(8);
        cancelButton.setLayoutParams(cancelParams);

        Button saveButton = new Button(requireContext());
        saveButton.setText("Save");
        saveButton.setBackgroundColor(getResources().getColor(android.R.color.black));
        saveButton.setTextColor(getResources().getColor(android.R.color.white));
        LinearLayout.LayoutParams saveParams = new LinearLayout.LayoutParams(
                0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        saveParams.setMarginStart(8);
        saveButton.setLayoutParams(saveParams);

        buttonLayout.addView(cancelButton);
        buttonLayout.addView(saveButton);

        ((LinearLayout) dialogView).addView(buttonLayout);

        AlertDialog dialog = builder.create();

        cancelButton.setOnClickListener(v -> dialog.dismiss());

        saveButton.setOnClickListener(v -> {
            String newName = dialogNameEdit.getText().toString().trim();
            updateProfile(newName);
            dialog.dismiss();
        });

        dialog.show();
    }
    private void openImageChooser() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }
    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
            imageUri = data.getData();
            // Update dialog image
            updateDialogImage(imageUri);
            // Upload the image
            uploadProfileImage(imageUri);
        }
    }
    private void updateDialogImage(Uri uri) {
        if (dialogProfileImage != null) {
            Glide.with(requireContext())
                    .load(uri)
                    .placeholder(R.drawable.ic_profile)
                    .error(R.drawable.ic_profile)
                    .into(dialogProfileImage);
        }
    }
    private void uploadProfileImage(Uri imageUri) {
        StorageReference profilePicRef = storage.getReference().child("profile_pics/" + userId + ".jpg");
        profilePicRef.putFile(imageUri)
                .addOnSuccessListener(taskSnapshot -> profilePicRef.getDownloadUrl()
                        .addOnSuccessListener(uri -> {
                            // Update profile picture URL in Firestore
                            db.collection("users").document(userId)
                                    .update("profilePicUrl", uri.toString())
                                    .addOnSuccessListener(aVoid -> {
                                        // Load the new image
                                        loadProfileImage(uri);
                                        if (isAdded()) {
                                            Toast.makeText(getContext(), "Profile picture updated successfully", Toast.LENGTH_SHORT).show();
                                        }
                                    })
                                    .addOnFailureListener(e -> {
                                        if (isAdded()) {
                                            Toast.makeText(getContext(), "Failed to update profile picture URL", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                        }))
                .addOnFailureListener(e -> {
                    if (isAdded()) {
                        Toast.makeText(getContext(), "Failed to upload new profile picture", Toast.LENGTH_SHORT).show();
                    }
                });
    }
    private void loadProfileImage(Uri uri) {
        if (isAdded()) {
            Glide.with(requireContext())
                    .load(uri)
                    .placeholder(R.drawable.ic_profile)
                    .error(R.drawable.ic_profile)
                    .into(profileImageView);
        }
    }
    private void updateProfile(String newName) {
        // Update name in Firestore
        db.collection("users").document(userId)
                .update("name", newName)
                .addOnSuccessListener(aVoid -> {
                    if (isAdded()) {
                        nameTextView.setText(newName);
                        Toast.makeText(getContext(), "Profile updated successfully", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(e -> {
                    if (isAdded()) {
                        Toast.makeText(getContext(), "Failed to update profile", Toast.LENGTH_SHORT).show();
                    }
                });

        // Update profile picture if a new one was selected
        if (imageUri != null) {
            StorageReference profilePicRef = storage.getReference().child("profile_pics/" + userId + ".jpg");
            profilePicRef.putFile(imageUri)
                    .addOnSuccessListener(taskSnapshot -> profilePicRef.getDownloadUrl()
                            .addOnSuccessListener(uri -> {
                                if (isAdded()) {
                                    // Update profile picture URL in Firestore
                                    db.collection("users").document(userId)
                                            .update("profilePicUrl", uri.toString());

                                    loadProfileImage(uri);
                                    updateDialogImage(uri);
                                }
                            }))
                    .addOnFailureListener(e -> {
                        if (isAdded()) {
                            Toast.makeText(getContext(), "Failed to upload new profile picture", Toast.LENGTH_SHORT).show();
                        }
                    });
        }
        refreshProfileData();
    }
    private void refreshProfileData() {
        loadUserProfile();
        loadUserPosts();
    }


}
