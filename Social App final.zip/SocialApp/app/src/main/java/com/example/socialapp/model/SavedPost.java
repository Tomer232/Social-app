package com.example.socialapp.model;

import com.google.firebase.Timestamp;

public class SavedPost {
    private String postId;
    private String postOwnerId;
    private String savedByUserId;
    private String imageUrl;
    private Timestamp timestamp;

    public SavedPost() {}

    public SavedPost(String postId, String postOwnerId, String savedByUserId, String imageUrl, Timestamp timestamp) {
        this.postId = postId;
        this.postOwnerId = postOwnerId;
        this.savedByUserId = savedByUserId;
        this.imageUrl = imageUrl;
        this.timestamp = timestamp;
    }

    // Getters and setters
    public String getPostId() {
        return postId;
    }

    public void setPostId(String postId) {
        this.postId = postId;
    }

    public String getPostOwnerId() {
        return postOwnerId;
    }

    public void setPostOwnerId(String postOwnerId) {
        this.postOwnerId = postOwnerId;
    }

    public String getSavedByUserId() {
        return savedByUserId;
    }

    public void setSavedByUserId(String savedByUserId) {
        this.savedByUserId = savedByUserId;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }
}