package com.example.socialapp;

import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends BaseActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        View mainContent = findViewById(R.id.main);
        ViewCompat.setOnApplyWindowInsetsListener(mainContent, (v, insets) -> {
            int systemBars = WindowInsetsCompat.Type.systemBars();
            int ime = WindowInsetsCompat.Type.ime();

            int bottomInset = insets.getInsets(systemBars).bottom;
            int imeInset = insets.getInsets(ime).bottom;

            v.setPadding(0, 0, 0, Math.max(bottomInset, imeInset));

            return WindowInsetsCompat.CONSUMED;
        });

        setupBottomNavigation(savedInstanceState);
    }
}